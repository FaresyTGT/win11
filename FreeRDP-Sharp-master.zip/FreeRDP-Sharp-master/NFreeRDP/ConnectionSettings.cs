﻿using System;

namespace NFreeRDP
{
	public class ConnectionSettings
	{
		public int port;
		public string hostname;
		public string username;
		public string domain;
		public string password;
	}
}
